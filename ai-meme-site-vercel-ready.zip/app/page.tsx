'use client';
import { useState } from 'react';

export default function Home() {
  const [input, setInput] = useState('');
  const [response, setResponse] = useState('');

  async function askAI() {
    const res = await fetch('/api/ai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ input })
    });
    const data = await res.json();
    setResponse(data.output);
  }

  return (
    <main className="container">
      <h1>AI MEME CORE</h1>
      <p className="subtitle">SYSTEM ONLINE // DEGEN DATA ENABLED</p>

      <textarea
        placeholder="Type something foolish..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />

      <button onClick={askAI}>EXECUTE</button>

      {response && (
        <div className="response">
          <span>AI RESPONSE:</span>
          <p>{response}</p>
        </div>
      )}
    </main>
  );
}