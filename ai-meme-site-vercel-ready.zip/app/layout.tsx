import './globals.css';

export const metadata = {
  title: 'AI MEME CORE',
  description: 'High-tech AI powered meme interface'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}