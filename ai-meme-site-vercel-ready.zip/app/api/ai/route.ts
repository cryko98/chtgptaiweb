import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  const { input } = await req.json();

  const res = await fetch(
    'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=' +
      process.env.GEMINI_API_KEY,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: input }] }]
      })
    }
  );

  const data = await res.json();
  const output =
    data?.candidates?.[0]?.content?.parts?.[0]?.text ||
    'AI FAILED TO RESPOND';

  return NextResponse.json({ output });
}